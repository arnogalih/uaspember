import org.gradle.api.tasks.Delete
import org.gradle.api.initialization.resolve.RepositoriesMode

// Repositories Global
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

// Mengubah direktori build utama (opsional)
val newBuildDir = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.set(newBuildDir)

subprojects {
    val subBuildDir = newBuildDir.dir(name)
    layout.buildDirectory.set(subBuildDir)
}

// Membersihkan folder build
tasks.register<Delete>("clean") {
    delete(rootProject.buildDir)
}
