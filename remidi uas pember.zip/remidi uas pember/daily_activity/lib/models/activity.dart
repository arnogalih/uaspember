class Activity {
  String id;
  String name;
  String description;
  String category;
  String date;
  String photo;

  Activity({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.date,
    required this.photo,
  });

  factory Activity.fromMap(Map<dynamic, dynamic> map, String key) {
    return Activity(
      id: key,
      name: map['name'],
      description: map['description'],
      category: map['category'],
      date: map['date'],
      photo: map['photo'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'description': description,
      'category': category,
      'date': date,
      'photo': photo,
    };
  }
}
