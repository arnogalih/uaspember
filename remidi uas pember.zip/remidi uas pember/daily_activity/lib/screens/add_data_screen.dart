import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/activity.dart';
import '../services/database_service.dart';

class AddDataScreen extends StatefulWidget {
  @override
  _AddDataScreenState createState() => _AddDataScreenState();
}

class _AddDataScreenState extends State<AddDataScreen> {
  final _formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final descController = TextEditingController();
  final dateController = TextEditingController();
  String selectedCategory = 'Lainnya';

  final dbService = DatabaseService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Tambah Data")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              buildTextField("Nama Kegiatan", nameController),
              SizedBox(height: 10),
              DropdownButtonFormField(
                value: selectedCategory,
                items: ['Kuliah', 'Organisasi', 'Lainnya']
                    .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                    .toList(),
                onChanged: (val) => setState(() => selectedCategory = val.toString()),
                decoration: InputDecoration(border: OutlineInputBorder()),
              ),
              SizedBox(height: 10),
              buildTextField("Tanggal", dateController),
              SizedBox(height: 10),
              buildTextField("Deskripsi", descController, maxLines: 3),
              SizedBox(height: 20),
              Icon(Icons.camera_alt, size: 60),
              SizedBox(height: 20),
              ElevatedButton(
                child: Text("Simpan"),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    final id = Uuid().v4();
                    final newActivity = Activity(
                      id: id,
                      name: nameController.text,
                      description: descController.text,
                      category: selectedCategory,
                      date: dateController.text,
                      photo: 'assets/placeholder.jpg',
                    );
                    dbService.addActivity(newActivity);
                    Navigator.pop(context);
                  }
                },
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget buildTextField(String label, TextEditingController controller, {int maxLines = 1}) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: label, border: OutlineInputBorder()),
      validator: (val) => val!.isEmpty ? 'Harus diisi' : null,
    );
  }
}
