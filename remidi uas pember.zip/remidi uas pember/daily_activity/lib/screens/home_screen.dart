import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import '../models/activity.dart';
import '../services/database_service.dart';
import 'add_data_screen.dart';
import 'detail_screen.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});

  final dbService = DatabaseService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Daily Activity')),
      body: StreamBuilder<DatabaseEvent>(
        stream: dbService.getActivitiesQuery().onValue,
        builder: (context, snapshot) {
          if (snapshot.hasData && snapshot.data!.snapshot.value != null) {
            final data = Map<String, dynamic>.from(
              snapshot.data!.snapshot.value as Map,
            );

            final List<Activity> activities = data.entries.map((entry) {
              return Activity.fromMap(entry.value, entry.key);
            }).toList();

            return Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: activities.length,
                    itemBuilder: (context, index) {
                      final activity = activities[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: ListTile(
                          leading: Image.asset('assets/placeholder.jpg', width: 50),
                          title: Text(activity.name),
                          subtitle: Text(
                            'Tanggal: ${activity.date}\n${activity.category}',
                          ),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => DetailScreen(activity: activity),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.add),
                      label: const Text("Tambah Data"),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => AddDataScreen()),
                        );
                      },
                    ),
                  ),
                ),
              ],
            );
          }

          // Jika belum ada data
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('Belum ada data'),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  icon: const Icon(Icons.add),
                  label: const Text("Tambah Data"),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => AddDataScreen()),
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),

      // Tombol tambah di pojok kanan bawah
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => AddDataScreen()),
          );
        },
      ),
    );
  }
}

// nama lengkap = arno galih candra kartika
// NIM = 230441100033
// Kelas = pember b
// Nama Asprak = abdul jabbar ramadhani
