import 'package:flutter/material.dart';
import '../models/activity.dart';
import '../services/database_service.dart';

class DetailScreen extends StatelessWidget {
  final Activity activity;
  final dbService = DatabaseService();

  DetailScreen({required this.activity});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Detail Tugas")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            buildField("Nama Kegiatan", activity.name),
            buildField("Kategori", activity.category),
            buildField("Tanggal", activity.date),
            buildField("Deskripsi", activity.description, maxLines: 3),
            SizedBox(height: 10),
            Text("Dokumentasi:"),
            SizedBox(height: 10),
            Image.asset(activity.photo, height: 150),
            SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: Text("Hapus"),
              onPressed: () {
                dbService.deleteActivity(activity.id);
                Navigator.pop(context);
              },
            )
          ],
        ),
      ),
    );
  }

  Widget buildField(String label, String value, {int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextFormField(
        readOnly: true,
        initialValue: value,
        maxLines: maxLines,
        decoration: InputDecoration(labelText: label, border: OutlineInputBorder()),
      ),
    );
  }
}
