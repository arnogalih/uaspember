import 'package:firebase_database/firebase_database.dart';
import '../models/activity.dart';

class DatabaseService {
  final dbRef = FirebaseDatabase.instance.ref().child('activities');

  Future<void> addActivity(Activity activity) async {
    await dbRef.child(activity.id).set(activity.toMap());
  }

  Future<void> deleteActivity(String id) async {
    await dbRef.child(id).remove();
  }

  Query getActivitiesQuery() {
    return dbRef;
  }
}
